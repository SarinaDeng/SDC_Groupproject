var moment = require('moment');

var portNumber = 8716;

var mysql = require('mysql');

// MySQL Connection Variables
var connection = mysql.createConnection({
    host: 'dev.spatialdatacapture.org',
    user: 'ucfnyyy',
    password: 'donefibuhu',
    database: 'ucfnyyy'
});

connection.connect();

//  Setup the Express Server
var express = require('express')
var app = express()
app.set('view engine', 'ejs');

// Provides the static folders we have added in the project to the web server.
app.use(express.static(__dirname + '/js'));
app.use(express.static(__dirname + '/css'));
app.use(express.static(__dirname + '/images'));

// Default API Endpoint - return the index.ejs file in the views folder
app.get('/', function(req, res) {
    return res.render('index');
})


// adjust the content
app.get('/commuting', function(req, res) {
    // Alows data to be downloaded from the server with security concerns
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-WithD");

    // SQL Statement to run
    var sql = "select * from commuting";

    // Log it on the screen for debugging
    console.log(sql);

    // Run the SQL Query
    connection.query(sql, function(err, rows, fields) {
        if (err) console.log("Err:" + err);
        if (rows != undefined) {
            // If we have data that comes bag send it to the user.
            res.send(rows);
        } else {
            res.send("");
        }
    });
});

app.get('/other_transport_2', function(req, res) {
    // Alows data to be downloaded from the server with security concerns
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-WithD");

    // SQL Statement to run
    var sql = "select * from other_transport_2";

    // Log it on the screen for debugging
    console.log(sql);

    // Run the SQL Query
    connection.query(sql, function(err, rows, fields) {
        if (err) console.log("Err:" + err);
        if (rows != undefined) {
            // If we have data that comes bag send it to the user.
            res.send(rows);
        } else {
            res.send("");
        }
    });
});

app.get('/personal_transport_2', function(req, res) {
    // Alows data to be downloaded from the server with security concerns
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-WithD");

    // SQL Statement to run
    var sql = "select * from personal_transport_2";

    // Log it on the screen for debugging
    console.log(sql);

    // Run the SQL Query
    connection.query(sql, function(err, rows, fields) {
        if (err) console.log("Err:" + err);
        if (rows != undefined) {
            // If we have data that comes bag send it to the user.
            res.send(rows);
        } else {
            res.send("");
        }
    });
});


app.get('/public_transport_2', function(req, res) {
    // Alows data to be downloaded from the server with security concerns
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-WithD");

    // SQL Statement to run
    var sql = "select * from public_transport_2";

    // Log it on the screen for debugging
    console.log(sql);

    // Run the SQL Query
    connection.query(sql, function(err, rows, fields) {
        if (err) console.log("Err:" + err);
        if (rows != undefined) {
            // If we have data that comes bag send it to the user.
            res.send(rows);
        } else {
            res.send("");
        }
    });
});


// Setup the server and print a string to the screen when server is ready
var server = app.listen(portNumber, function() {
    var host = server.address().address;
    var port = server.address().port;
    console.log('App listening at http://%s:%s', host, port);
})


function mysql_real_escape_string(str) {
    return str.replace(/[\0\x08\x09\x1a\n\r"'\\\%]/g, function(char) {
        switch (char) {
            case "\0":
                return "\\0";
            case "\x08":
                return "\\b";
            case "\x09":
                return "\\t";
            case "\x1a":
                return "\\z";
            case "\n":
                return "\\n";
            case "\r":
                return "\\r";
            case "\"":
            case "'":
            case "\\":
            case "%":
                return "\\" + char; // prepends a backslash to backslash, percent,
                // and double/single quotes
        }
    });
}